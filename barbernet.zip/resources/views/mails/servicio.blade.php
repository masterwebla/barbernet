<!DOCTYPE html>
<html>
<head>
	<title>Nuevo Servicio Creado</title>
</head>
<body>
	<h1>Nuevo Servicio {{$nombreto}}</h1>
	<p>
		Nombre: {{$nombreto}}<br>
		Precio: {{$precioto}}<br>
		Email de quien lo crea: {{$emailto}}
	</p>
</body>
</html>