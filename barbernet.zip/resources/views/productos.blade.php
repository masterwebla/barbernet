<!DOCTYPE html>
<html>
<head>
	<title>Productos</title>
</head>
<body>
	<h1>Catalogo de productos</h1>
	<p>Aqui van los productos</p>
</body>
</html>