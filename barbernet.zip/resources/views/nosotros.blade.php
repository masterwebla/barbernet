@extends('master')
@section('titulo','Nosotros')

@section('contenido')
	<h1>Nosotros</h1>
	<p>texto de quienes somos</p>
@endsection