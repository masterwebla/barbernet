<?php $__env->startSection('titulo','Bienvenido a Barbernet'); ?>

<?php $__env->startSection('contenido'); ?>
	<?php echo $__env->make('parciales.carrusel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="container">
		<div id="demo" class="text-center">
			<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="white-panel">
					<h2 class="text-center"><?php echo e($producto->nombre); ?></h2>
					<img class="imgcatalogo" src="<?php echo e(asset('images/'.$producto->imagen.'')); ?>">
					<h3>$<?php echo e(number_format($producto->precio,0,'','.')); ?></h3>
					<p>
						<a class="btn btn-info" href="<?php echo e(route('producto-detalles',$producto->id)); ?>">Ver mas</a>
						<a class="btn btn-success" href="<?php echo e(route('carrito-agregar',$producto->id)); ?>">Comprar <i class="fa fa-shopping-cart"></i></a>
					</p>
				</div>				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>