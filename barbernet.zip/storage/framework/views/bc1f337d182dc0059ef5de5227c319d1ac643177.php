<?php $__env->startSection('titulo','Listado de Cupones'); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container text-center">
		<h1>Listado de Cupones</h1>
		<a class="btn btn-primary" href="<?php echo e(route('cupones.create')); ?>">Crear Nuevo</a>
		<br><br>
		<table class="table table-bordered table-striped table-hover">
			<thead>
				<tr>
					<th>ID</th>
					<th>Codigo</th>
					<th>Porcentaje</th>
					<th>Fecha Caducidad</th>
					<th>Editar</th>
					<th>Borrar</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $cupones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($cupon->id); ?></td>
						<td><?php echo e($cupon->codigo); ?></td>
						<td><?php echo e($cupon->porcentaje); ?></td>
						<td><?php echo e($cupon->fecha_caducidad); ?></td>
						<td>
							<a href="<?php echo e(route('cupones.edit',$cupon->id)); ?>" class="btn btn-warning">
								<i class="fa fa-pencil-square fa-2x"></i>
							</a>
						</td>
						<td>
							<?php echo Form::open(['route' => ['cupones.destroy', $cupon->id]]); ?>

		        				<input type="hidden" name="_method" value="DELETE">
		        				<button onClick="return confirm('Eliminar cupon?')" class="btn btn-danger">
		        					<i class="fa fa-trash-o fa-2x"></i>
		        				</button>
		        			<?php echo Form::close(); ?>

						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<?php echo e($cupones->links()); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>