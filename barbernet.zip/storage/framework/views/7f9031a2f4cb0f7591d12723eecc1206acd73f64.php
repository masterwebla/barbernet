<?php $__env->startSection('titulo','Nosotros'); ?>

<?php $__env->startSection('contenido'); ?>
	<h1>Nosotros</h1>
	<p>texto de quienes somos</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>