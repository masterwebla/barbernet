<?php $__env->startSection('titulo','Carrito de Compras'); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container text-center">
		<div class="page-header">
			<h1><i class="fa fa-shopping-cart"></i> Carrito de Compras</h1>
		</div>
		<?php if($carrito): ?>
			<div>
				<a href="<?php echo e(route('carrito-vaciar')); ?>" class="btn btn-danger"><i class="fa fa-trash"></i> Vaciar Carrito</a><br><br>
			</div>
			<div class="table-responsive">
				<table class="table table-striped table-hover table-bordered">
					<thead>
						<tr>
							<th>Imagen</th>
							<th>Producto</th>
							<th>Precio</th>
							<th>Cantidad</th>
							<th>Subtotal</th>
							<th>Eliminar</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><img src="<?php echo e(asset('images/'.$producto->imagen.'')); ?>" width="50" class="img-thumbnail"></td>
								<td><?php echo e($producto->nombre); ?></td>
								<td>$<?php echo e(number_format($producto->precio,0)); ?></td>

								<td>
									<input type="number" min="1" max="<?php echo e($producto->cantidad); ?>" id="producto_<?php echo e($producto->id); ?>" value="<?php echo e($producto->cantcompra); ?>">
									<a class="btn btn-warning act" data-href="<?php echo e(route('carrito-actualizar', $producto->id)); ?>" data-id="<?php echo e($producto->id); ?>">
										<i class="fa fa-refresh"></i>
									</a>
								</td>



								<td>$<?php echo e(number_format($producto->precio * $producto->cantcompra,0)); ?></td>
								<td><a class="btn btn-danger" href="<?php echo e(route('carrito-borrar',$producto->id)); ?>"><i class="fa fa-remove"></i></a></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		<?php else: ?>
			<h2><span class="label label-danger">No hay productos en el carrito :(</span></h2>

		<?php endif; ?>
		<div class="text-center">
			<a class="btn btn-primary" href="<?php echo e(route('inicio')); ?>"><i class="fa fa-chevron-circle-left"></i> Seguir Comprando</a>
			<?php if($carrito): ?>
				<a class="btn btn-success" href="<?php echo e(route('ordenar')); ?>">Ordenar <i class="fa fa-chevron-circle-right"></i></a>
			<?php endif; ?>

		</div>

		<hr>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>