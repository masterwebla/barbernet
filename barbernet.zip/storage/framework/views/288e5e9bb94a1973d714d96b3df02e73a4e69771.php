<?php $__env->startSection('titulo','Nosotros'); ?>

<?php $__env->startSection('contenido'); ?>

	<h1>Servicios</h1>
	<ul>
		<?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
			<li><?php echo e($servicio->nombre); ?> - $<?php echo e($servicio->precio); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>