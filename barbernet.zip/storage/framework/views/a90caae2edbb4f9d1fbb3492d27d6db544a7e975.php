<?php $__env->startSection('titulo','Editar Cupones'); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container text-center">
		<h1>Editar Cupón</h1>
		<?php echo $__env->make('parciales.errores', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo Form::model($cupon,['route'=>['cupones.update',$cupon->id],'method'=>'PUT']); ?>

			<div class="form-group">
				<?php echo Form::label('Codigo'); ?>

				<?php echo Form::text('codigo', null, [
						'class'=>'form-control',
						'placeholder'=>'Codigo...'
					]); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('Porcentaje'); ?>

				<?php echo Form::number('porcentaje', null, [
						'class'=>'form-control',
						'placeholder'=>'Porcentaje...'
					]); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('Fecha'); ?>

				<?php echo Form::date('fecha_caducidad', null, [
						'class'=>'form-control',
						'placeholder'=>'Fecha...'
					]); ?>

			</div>
			<a class="btn btn-danger" href="<?php echo e(route('cupones.index')); ?>">Cancelar</a>
			<?php echo Form::submit('Guardar',['class'=>'btn btn-primary']); ?>

		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>