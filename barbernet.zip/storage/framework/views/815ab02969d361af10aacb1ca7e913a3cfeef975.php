<?php $__env->startSection('titulo','Crear Servicio'); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container text-center">
		<h1>Crear Nuevo Servicio</h1>
		<?php echo $__env->make('parciales.errores', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo Form::open(['route'=>'servicios.store']); ?>

			<?php echo $__env->make('admin.servicios.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<a class="btn btn-danger" href="<?php echo e(route('servicios.index')); ?>">Cancelar</a>
			<?php echo Form::submit('Guardar',['class'=>'btn btn-primary']); ?>

		<?php echo Form::close(); ?>

		<hr>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>