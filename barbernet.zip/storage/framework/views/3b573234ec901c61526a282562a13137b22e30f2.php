<div class="alert alert-info text-center">
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
    </button>
	<h3><?php echo e(\Session::get('mensaje')); ?></h3>
</div>