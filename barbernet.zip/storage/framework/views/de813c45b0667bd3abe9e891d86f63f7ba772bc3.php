<!DOCTYPE html>
<html>
<head>
	<title>Nuevo Servicio Creado</title>
</head>
<body>
	<h1>Nuevo Servicio <?php echo e($nombreto); ?></h1>
	<p>
		Nombre: <?php echo e($nombreto); ?><br>
		Precio: <?php echo e($precioto); ?><br>
		Email de quien lo crea: <?php echo e($emailto); ?>

	</p>
</body>
</html>