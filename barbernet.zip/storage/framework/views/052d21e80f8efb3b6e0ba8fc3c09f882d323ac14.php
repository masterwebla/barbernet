<?php $__env->startSection('titulo','Detalles del producto'); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container text-center">
		<h1>Detalles del Producto</h1>
		<div class="row">
			<div class="col-md-5">
				<img src="<?php echo e(asset('images/'.$producto->imagen.'')); ?>" class="img-responsive">
			</div>
			<div class="col-md-7">
				<h2><?php echo e($producto->nombre); ?></h2>
				<p><?php echo e($producto->descripcion); ?></p>
				<h4>$<?php echo e(number_format($producto->precio)); ?></h4>
				<a class="btn btn-success" href="#">Agregar Carrito <i class="fa fa-shopping-cart"></i></a>
			</div>
		</div>
		
		<a class="btn btn-primary" href="<?php echo e(route('inicio')); ?>">Volver</a>
		<hr>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>