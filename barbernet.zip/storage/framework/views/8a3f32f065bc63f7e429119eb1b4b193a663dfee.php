<?php $__env->startSection('titulo','Listado de Productos'); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container text-center">
		<h1>Listado de Productos</h1>
		<a class="btn btn-primary" href="<?php echo e(route('productos.create')); ?>">Crear Nuevo</a>
		<br><br>
		<table class="table table-bordered table-striped table-hover">
			<thead>
				<tr>
					<th>Nombre</th>
					<th>Precio</th>
					<th>Cantidad</th>
					<th>Estado</th>
					<th>Imagen</th>
					<th>Editar</th>
					<th>Borrar</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($producto->nombre); ?></td>
						<td>$<?php echo e(number_format($producto->precio,0,'', '.')); ?></td>
						<td><?php echo e($producto->cantidad); ?></td>
						<td><?php echo e($producto->estado->nombre); ?></td>
	<td><img src="<?php echo e(asset('images/'.$producto->imagen.'')); ?>" width="70" class="img-thumbnail"></td>
						<td>
							<a href="<?php echo e(route('productos.edit',$producto->id)); ?>" class="btn btn-warning">
								<i class="fa fa-pencil-square fa-2x"></i>
							</a>
						</td>
						<td>
							<?php echo Form::open(['route' => ['productos.destroy', $producto->id]]); ?>

		        				<input type="hidden" name="_method" value="DELETE">
		        				<button onClick="return confirm('Eliminar producto?')" class="btn btn-danger">
		        					<i class="fa fa-trash-o fa-2x"></i>
		        				</button>
		        			<?php echo Form::close(); ?>

						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<?php echo e($productos->links()); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>