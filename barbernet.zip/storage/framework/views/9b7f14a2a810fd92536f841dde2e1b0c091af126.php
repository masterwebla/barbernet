<!DOCTYPE html>
<html>
<head>
  <title>Barbernet - <?php echo $__env->yieldContent('titulo'); ?></title>
  <link href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/lumen/bootstrap.min.css" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>">
</head>
<body>
  
  <?php echo $__env->make('parciales.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php if(\Session::has('mensaje')): ?>
	 <?php echo $__env->make('parciales.mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php endif; ?>
  <?php echo $__env->yieldContent('contenido'); ?>
  <?php echo $__env->make('parciales.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="<?php echo e(asset('js/pinterest_grid.js')); ?>"></script>
  <script src="<?php echo e(asset('js/principal.js')); ?>"></script>
</body>
</html>