<?php $__env->startSection('titulo','Listado de Perfiles'); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container text-center">
		<h1>Listado de Perfiles</h1>
		<a class="btn btn-primary" href="<?php echo e(route('perfiles.create')); ?>">Crear Nuevo</a>
		<br><br>
		<table class="table table-bordered table-striped table-hover">
			<thead>
				<tr>
					<th>ID</th>
					<th>Nombre</th>
					<th>Editar</th>
					<th>Borrar</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $perfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($perfil->id); ?></td>
						<td><?php echo e($perfil->nombre); ?></td>
						<td>
							<a href="<?php echo e(route('perfiles.edit',$perfil->id)); ?>" class="btn btn-warning">
								<i class="fa fa-pencil-square fa-2x"></i>
							</a>
						</td>
						<td>
							<?php echo Form::open(['route' => ['perfiles.destroy', $perfil->id]]); ?>

		        				<input type="hidden" name="_method" value="DELETE">
		        				<button onClick="return confirm('Eliminar perfil?')" class="btn btn-danger">
		        					<i class="fa fa-trash-o fa-2x"></i>
		        				</button>
		        			<?php echo Form::close(); ?>

						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<?php echo e($perfiles->links()); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>