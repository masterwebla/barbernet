<?php $__env->startSection('titulo', 'Detalles del Pedido'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
	<div class="page-header text-center">
		<h1><i class="fa fa-shopping-cart"></i> Detalles de la Orden</h1>
	</div>
	<div>
		<div class="row">
			<div class="col-md-offset-3 col-md-6">
				<h3 class="text-center">Mis Datos</h3>
				<div class="table-responsive">		
					<table class="table table-striped table-hover table-bordered">
						<tr><td><strong>Nombre</strong></td><td><?php echo e(Auth::user()->name); ?></td></tr>
						<tr><td><strong>Email</strong></td><td><?php echo e(Auth::user()->email); ?></td></tr>
					</table>
				</div>
			</div>			
		</div>
		<div class="row">
			<div class="col-md-offset-2 col-md-8">
				<h3 class="text-center">Mis Productos</h3>
				<div class="table-responsive">			
					<table class="table table-striped table-hover table-bordered">
						<thead>
							<tr class="text-center">
								<td><strong>Producto</strong></td>
								<td><strong>Cantidad</strong></td>
								<td><strong>Precio</strong></td>
							</tr>	
						</thead>
						<tbody>
							<?php $total = 0; ?>
							<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($producto->producto->nombre); ?></td>
									<td><?php echo e($producto->cantidad); ?></td>
									<td class="text-right">$<?php echo e(number_format($producto->precio*$producto->cantidad,0)); ?></td>
									<?php $total+= $producto->precio*$producto->cantidad; ?>
								</tr>	
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
						</tbody>			
					</table>
					<h3 class="text-center">Total: $<?php echo e(number_format($total,0)); ?></h3>
				</div>
			</div>
		</div>		
	</div>	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>