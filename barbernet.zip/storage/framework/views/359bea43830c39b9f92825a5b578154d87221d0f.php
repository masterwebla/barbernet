<?php $__env->startSection('titulo','Editar Perfiles'); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container text-center">
		<h1>Editar Perfil</h1>
		<?php echo $__env->make('parciales.errores', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo Form::model($perfil,['route'=>['perfiles.update',$perfil->id],'method'=>'PUT']); ?>

			<div class="form-group">
				<?php echo Form::label('Nombre'); ?>

				<?php echo Form::text('nombre', null, [
						'class'=>'form-control',
						'placeholder'=>'Nombre del perfil...'
					]); ?>

			</div>
			<a class="btn btn-danger" href="<?php echo e(route('perfiles.index')); ?>">Cancelar</a>
			<?php echo Form::submit('Guardar',['class'=>'btn btn-primary']); ?>

		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>