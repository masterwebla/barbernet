			<div class="form-group">
				<?php echo Form::label('Nombre'); ?>

				<?php echo Form::text('nombre', null, [
						'class'=>'form-control',
						'required'=>'required', 
						'placeholder'=>'Nombre...'
					]); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('Precio'); ?>

				<?php echo Form::number('precio', null, [
						'class'=>'form-control',
						'required'=>'required', 
						'placeholder'=>'Precio...'
					]); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('Descripcion'); ?>

				<?php echo Form::textarea('descripcion', null, [
						'class'=>'form-control',
						'placeholder'=>'Descripcion...'
					]); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('Cantidad'); ?>

				<?php echo Form::number('cantidad', null, [
						'class'=>'form-control',
						'required'=>'required', 
						'placeholder'=>'Cantidad...'
					]); ?>

			</div>
			<div class="form-group">
		        <label>Estados</label>
		        <?php echo Form::select('idestado', $estados, null, ['class' => 'form-control',
		        	'placeholder'=>'Seleccione el estado',
		        	'required'=>'required'
		        ]); ?>

		    </div>

			<div class="form-group">
				<?php echo Form::label('Puntos'); ?>

				<?php echo Form::number('puntos', null, [
						'class'=>'form-control',
						'required'=>'required', 
						'placeholder'=>'Puntos...'
					]); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('Imagen Principal (800 * 600 px)'); ?>

				<input type="file" name="imagen">
			</div>